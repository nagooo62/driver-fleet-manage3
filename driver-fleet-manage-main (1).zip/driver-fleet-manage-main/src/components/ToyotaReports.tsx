import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { 
  ShoppingCart, 
  Users, 
  Percent, 
  Database, 
  CheckCircle, 
  AlertCircle, 
  XCircle,
  Upload,
  Download,
  Trash2,
  RefreshCw,
  Save,
  RotateCcw,
  Wifi,
  WifiOff
} from 'lucide-react';

interface ToyotaRecord {
  name: string;
  rep_id: string;
  date: string;
  completed_orders: number;
  percentage: number;
  city: string;
  phone: string;
  validation_status: 'valid' | 'warning' | 'error';
  validation_errors?: string[];
  validation_warnings?: string[];
}

interface ValidationRules {
  [key: string]: {
    required?: boolean;
    type?: string;
    min?: number;
    max?: number;
    minLength?: number;
    pattern?: RegExp;
  };
}

const ToyotaReports: React.FC = () => {
  const [data, setData] = useState<ToyotaRecord[]>([]);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const [dateFilter, setDateFilter] = useState('today');
  const [activeTab, setActiveTab] = useState('dashboard');

  const validationRules: ValidationRules = {
    name: { required: true, minLength: 2 },
    rep_id: { required: true, pattern: /^REP\d{3}$/ },
    completed_orders: { required: true, type: 'number', min: 0 },
    percentage: { required: true, type: 'number', min: 0, max: 100 },
    date: { required: true, type: 'date' }
  };

  useEffect(() => {
    loadLocalData();
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const loadLocalData = () => {
    try {
      const savedData = localStorage.getItem('toyotaReportsData');
      if (savedData) {
        const parsed = JSON.parse(savedData);
        setData(parsed.data || []);
        setLastUpdate(new Date(parsed.timestamp));
      } else {
        loadSampleData();
      }
    } catch (error) {
      console.error('Error loading data:', error);
      loadSampleData();
    }
  };

  const loadSampleData = () => {
    const sampleData: ToyotaRecord[] = [
      {
        name: "أحمد محمد",
        rep_id: "REP001",
        date: new Date().toISOString().split('T')[0],
        completed_orders: 25,
        percentage: 85,
        city: "المدينة المنورة",
        phone: "+966501234567",
        validation_status: "valid"
      },
      {
        name: "سارة أحمد",
        rep_id: "REP002",
        date: new Date().toISOString().split('T')[0],
        completed_orders: 22,
        percentage: 78,
        city: "جدة",
        phone: "+966507654321",
        validation_status: "valid"
      },
      {
        name: "محمد علي",
        rep_id: "REP003",
        date: new Date().toISOString().split('T')[0],
        completed_orders: 30,
        percentage: 92,
        city: "المدينة المنورة",
        phone: "+966509876543",
        validation_status: "valid"
      },
      {
        name: "فاطمة حسن",
        rep_id: "REP004",
        date: new Date().toISOString().split('T')[0],
        completed_orders: 18,
        percentage: 72,
        city: "جدة",
        phone: "+966502468135",
        validation_status: "warning"
      },
      {
        name: "عبدالله خالد",
        rep_id: "REP005",
        date: new Date().toISOString().split('T')[0],
        completed_orders: 27,
        percentage: 88,
        city: "المدينة المنورة",
        phone: "+966508642097",
        validation_status: "valid"
      }
    ];
    setData(sampleData);
    setLastUpdate(new Date());
  };

  const saveLocalData = () => {
    try {
      const dataToSave = {
        data,
        timestamp: new Date().toISOString(),
        version: '2.0'
      };
      localStorage.setItem('toyotaReportsData', JSON.stringify(dataToSave));
      setLastUpdate(new Date());
    } catch (error) {
      console.error('Error saving data:', error);
    }
  };

  const getFilteredData = () => {
    const today = new Date();
    const todayStr = today.toISOString().split('T')[0];
    
    switch (dateFilter) {
      case 'today':
        return data.filter(item => item.date === todayStr);
      case 'yesterday':
        const yesterday = new Date(today);
        yesterday.setDate(yesterday.getDate() - 1);
        return data.filter(item => item.date === yesterday.toISOString().split('T')[0]);
      case 'week':
        const weekAgo = new Date(today);
        weekAgo.setDate(weekAgo.getDate() - 7);
        return data.filter(item => new Date(item.date) >= weekAgo);
      case 'month':
        const monthAgo = new Date(today);
        monthAgo.setMonth(monthAgo.getMonth() - 1);
        return data.filter(item => new Date(item.date) >= monthAgo);
      default:
        return data;
    }
  };

  const getStats = () => {
    const filteredData = getFilteredData();
    const totalOrders = filteredData.reduce((sum, item) => sum + item.completed_orders, 0);
    const avgPerformance = filteredData.length > 0 ? 
      Math.round(filteredData.reduce((sum, item) => sum + item.percentage, 0) / filteredData.length) : 0;
    const uniqueEmployees = new Set(filteredData.map(item => item.name)).size;
    const validRecords = filteredData.filter(item => item.validation_status === 'valid').length;
    const warningRecords = filteredData.filter(item => item.validation_status === 'warning').length;
    const errorRecords = filteredData.filter(item => item.validation_status === 'error').length;

    return {
      totalOrders,
      avgPerformance,
      uniqueEmployees,
      totalRecords: filteredData.length,
      validRecords,
      warningRecords,
      errorRecords
    };
  };

  const stats = getStats();
  const filteredData = getFilteredData();

  const StatusIndicator = () => (
    <div className="flex items-center gap-2 text-sm">
      {isOnline ? (
        <>
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
          <span>متصل - جاهز للمزامنة</span>
        </>
      ) : (
        <>
          <div className="w-2 h-2 bg-orange-500 rounded-full animate-pulse"></div>
          <span>وضع محلي - البيانات آمنة</span>
        </>
      )}
    </div>
  );

  return (
    <div className="container mx-auto p-6 space-y-6" dir="rtl">
      {/* Status Bar */}
      <Card className="glass">
        <CardContent className="p-4">
          <div className="flex justify-between items-center">
            <StatusIndicator />
            <div className="text-sm text-muted-foreground">
              المصدر: {isOnline ? 'سحابي + محلي' : 'محلي فقط'}
            </div>
            {lastUpdate && (
              <div className="text-sm text-muted-foreground">
                آخر تحديث: {lastUpdate.toLocaleString('ar-SA')}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Header */}
      <Card className="glass">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl font-bold">لوحة معلومات المندوبين - تويوتا</CardTitle>
          <p className="text-muted-foreground">نظام متقدم لإدارة ومتابعة أداء المندوبين</p>
        </CardHeader>
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="glass hover:shadow-lg transition-all duration-300">
          <CardContent className="p-6 text-center">
            <div className="text-4xl text-blue-500 mb-4">
              <ShoppingCart className="mx-auto" />
            </div>
            <div className="text-3xl font-bold text-blue-500 mb-2">{stats.totalOrders}</div>
            <div className="text-muted-foreground">إجمالي الطلبات</div>
          </CardContent>
        </Card>

        <Card className="glass hover:shadow-lg transition-all duration-300">
          <CardContent className="p-6 text-center">
            <div className="text-4xl text-green-500 mb-4">
              <Users className="mx-auto" />
            </div>
            <div className="text-3xl font-bold text-green-500 mb-2">{stats.uniqueEmployees}</div>
            <div className="text-muted-foreground">عدد المندوبين</div>
          </CardContent>
        </Card>

        <Card className="glass hover:shadow-lg transition-all duration-300">
          <CardContent className="p-6 text-center">
            <div className="text-4xl text-orange-500 mb-4">
              <Percent className="mx-auto" />
            </div>
            <div className="text-3xl font-bold text-orange-500 mb-2">{stats.avgPerformance}%</div>
            <div className="text-muted-foreground">متوسط الأداء</div>
          </CardContent>
        </Card>

        <Card className="glass hover:shadow-lg transition-all duration-300">
          <CardContent className="p-6 text-center">
            <div className="text-4xl text-purple-500 mb-4">
              <Database className="mx-auto" />
            </div>
            <div className="text-3xl font-bold text-purple-500 mb-2">{stats.totalRecords}</div>
            <div className="text-muted-foreground">إجمالي السجلات</div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Card className="glass">
        <CardContent className="p-6">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="w-full mb-6">
              <TabsTrigger value="dashboard">لوحة المعلومات</TabsTrigger>
              <TabsTrigger value="employees">المندوبين</TabsTrigger>
              <TabsTrigger value="upload">رفع البيانات</TabsTrigger>
              <TabsTrigger value="settings">الإعدادات</TabsTrigger>
            </TabsList>

            {/* Dashboard Tab */}
            <TabsContent value="dashboard" className="space-y-6">
              {/* Date Filters */}
              <div className="flex gap-2 justify-center flex-wrap">
                {[
                  { key: 'today', label: 'اليوم' },
                  { key: 'yesterday', label: 'أمس' },
                  { key: 'week', label: 'هذا الأسبوع' },
                  { key: 'month', label: 'هذا الشهر' },
                  { key: 'all', label: 'جميع البيانات' }
                ].map(filter => (
                  <Button
                    key={filter.key}
                    variant={dateFilter === filter.key ? "default" : "outline"}
                    onClick={() => setDateFilter(filter.key)}
                    className="min-w-[120px]"
                  >
                    {filter.label}
                  </Button>
                ))}
              </div>

              {/* Validation Stats */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="glass">
                  <CardContent className="p-6 text-center">
                    <CheckCircle className="mx-auto text-4xl text-green-500 mb-4" />
                    <div className="text-2xl font-bold text-green-500 mb-2">{stats.validRecords}</div>
                    <div className="text-muted-foreground">سجلات صحيحة</div>
                  </CardContent>
                </Card>

                <Card className="glass">
                  <CardContent className="p-6 text-center">
                    <AlertCircle className="mx-auto text-4xl text-orange-500 mb-4" />
                    <div className="text-2xl font-bold text-orange-500 mb-2">{stats.warningRecords}</div>
                    <div className="text-muted-foreground">تحذيرات</div>
                  </CardContent>
                </Card>

                <Card className="glass">
                  <CardContent className="p-6 text-center">
                    <XCircle className="mx-auto text-4xl text-red-500 mb-4" />
                    <div className="text-2xl font-bold text-red-500 mb-2">{stats.errorRecords}</div>
                    <div className="text-muted-foreground">أخطاء</div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Employees Tab */}
            <TabsContent value="employees" className="space-y-6">
              <div className="space-y-4">
                {filteredData.map((employee, index) => (
                  <Card key={employee.rep_id} className="glass">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-center">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="font-semibold text-lg">{employee.name}</h3>
                            <Badge variant={
                              employee.validation_status === 'valid' ? 'default' :
                              employee.validation_status === 'warning' ? 'secondary' : 'destructive'
                            }>
                              {employee.rep_id}
                            </Badge>
                          </div>
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                            <div>
                              <span className="text-muted-foreground">المدينة: </span>
                              <span>{employee.city}</span>
                            </div>
                            <div>
                              <span className="text-muted-foreground">الطلبات: </span>
                              <span className="font-semibold">{employee.completed_orders}</span>
                            </div>
                            <div>
                              <span className="text-muted-foreground">الأداء: </span>
                              <span className="font-semibold">{employee.percentage}%</span>
                            </div>
                            <div>
                              <span className="text-muted-foreground">التاريخ: </span>
                              <span>{new Date(employee.date).toLocaleDateString('ar-SA')}</span>
                            </div>
                          </div>
                        </div>
                        <div className="w-24">
                          <Progress value={employee.percentage} className="mb-2" />
                          <div className="text-center text-sm text-muted-foreground">
                            {employee.percentage}%
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Upload Tab */}
            <TabsContent value="upload" className="space-y-6">
              <div className="text-center space-y-6">
                <div>
                  <h3 className="text-xl font-semibold mb-4">رفع وتصدير البيانات</h3>
                  <p className="text-muted-foreground mb-6">
                    يمكنك رفع ملفات Excel أو CSV مع بيانات المندوبين الجديدة
                  </p>
                </div>
                
                <div className="flex justify-center gap-4 flex-wrap">
                  <Button className="flex items-center gap-2">
                    <Upload className="w-4 h-4" />
                    رفع الملف
                  </Button>
                  <Button variant="outline" className="flex items-center gap-2">
                    <Download className="w-4 h-4" />
                    تصدير البيانات
                  </Button>
                  <Button variant="outline" className="flex items-center gap-2">
                    <Trash2 className="w-4 h-4" />
                    مسح البيانات
                  </Button>
                </div>
              </div>
            </TabsContent>

            {/* Settings Tab */}
            <TabsContent value="settings" className="space-y-6">
              <div>
                <h3 className="text-xl font-semibold mb-6 text-center">إعدادات النظام المتقدمة</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                  <Card className="glass">
                    <CardContent className="p-6 text-center">
                      <Database className="mx-auto text-4xl text-blue-500 mb-4" />
                      <div className="text-2xl font-bold text-blue-500 mb-2">{data.length}</div>
                      <div className="text-muted-foreground">سجلات البيانات</div>
                    </CardContent>
                  </Card>

                  <Card className="glass">
                    <CardContent className="p-6 text-center">
                      <CheckCircle className="mx-auto text-4xl text-green-500 mb-4" />
                      <div className="text-2xl font-bold text-green-500 mb-2">{stats.validRecords}</div>
                      <div className="text-muted-foreground">سجلات صحيحة</div>
                    </CardContent>
                  </Card>

                  <Card className="glass">
                    <CardContent className="p-6 text-center">
                      <AlertCircle className="mx-auto text-4xl text-orange-500 mb-4" />
                      <div className="text-2xl font-bold text-orange-500 mb-2">{stats.warningRecords}</div>
                      <div className="text-muted-foreground">تحذيرات</div>
                    </CardContent>
                  </Card>

                  <Card className="glass">
                    <CardContent className="p-6 text-center">
                      <XCircle className="mx-auto text-4xl text-red-500 mb-4" />
                      <div className="text-2xl font-bold text-red-500 mb-2">{stats.errorRecords}</div>
                      <div className="text-muted-foreground">أخطاء</div>
                    </CardContent>
                  </Card>
                </div>

                <div className="flex justify-center gap-4 flex-wrap">
                  <Button onClick={loadLocalData} className="flex items-center gap-2">
                    <RefreshCw className="w-4 h-4" />
                    تحديث البيانات
                  </Button>
                  <Button onClick={saveLocalData} className="flex items-center gap-2">
                    <Save className="w-4 h-4" />
                    حفظ الإعدادات
                  </Button>
                  <Button 
                    variant="destructive" 
                    onClick={() => {
                      if (confirm('هل أنت متأكد من إعادة تعيين النظام؟')) {
                        localStorage.removeItem('toyotaReportsData');
                        loadSampleData();
                      }
                    }}
                    className="flex items-center gap-2"
                  >
                    <RotateCcw className="w-4 h-4" />
                    إعادة تعيين النظام
                  </Button>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default ToyotaReports;