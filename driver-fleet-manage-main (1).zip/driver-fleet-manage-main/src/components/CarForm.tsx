import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface Car {
  id?: string;
  plate: string;
  type: string;
  status: string;
  current_delegate_id?: string;
  delegation_start?: string;
  delegation_end?: string;
}

interface Driver {
  id: string;
  full_name: string;
}

interface CarFormProps {
  isOpen: boolean;
  onClose: () => void;
  car?: Car | null;
  onSave: () => void;
}

export function CarForm({ isOpen, onClose, car, onSave }: CarFormProps) {
  const [formData, setFormData] = useState<Car>({
    plate: car?.plate || "",
    type: car?.type || "",
    status: car?.status || "available",
    current_delegate_id: car?.current_delegate_id || "",
    delegation_start: car?.delegation_start || "",
    delegation_end: car?.delegation_end || "",
  });

  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchDrivers();
  }, []);

  const fetchDrivers = async () => {
    const { data, error } = await supabase
      .from("drivers")
      .select("id, full_name")
      .eq("status", "accepted");
    
    if (error) {
      console.error("Error fetching drivers:", error);
    } else {
      setDrivers(data || []);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const carData = {
        ...formData,
        current_delegate_id: formData.current_delegate_id || null,
        delegation_start: formData.delegation_start || null,
        delegation_end: formData.delegation_end || null,
      };

      if (car?.id) {
        // Update existing car
        const { error } = await supabase
          .from("cars")
          .update(carData)
          .eq("id", car.id);
        
        if (error) throw error;
        toast.success("تم تحديث السيارة بنجاح");
      } else {
        // Create new car
        const { error } = await supabase
          .from("cars")
          .insert(carData);
        
        if (error) throw error;
        toast.success("تم إضافة السيارة بنجاح");
      }
      
      onSave();
      onClose();
    } catch (error: any) {
      toast.error(error.message || "حدث خطأ");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px] glass-modal max-h-[90vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-right">
            {car ? "تعديل السيارة" : "إضافة سيارة جديدة"}
          </DialogTitle>
        </DialogHeader>
        
        <ScrollArea className="flex-1 pr-4">
          <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="plate" className="text-right block">رقم اللوحة</Label>
              <Input
                id="plate"
                value={formData.plate}
                onChange={(e) => setFormData({...formData, plate: e.target.value})}
                required
                className="text-right"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="type" className="text-right block">نوع السيارة</Label>
              <Input
                id="type"
                value={formData.type}
                onChange={(e) => setFormData({...formData, type: e.target.value})}
                required
                className="text-right"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="status" className="text-right block">الحالة</Label>
            <Select value={formData.status} onValueChange={(value) => setFormData({...formData, status: value})}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="available">متاحة</SelectItem>
                <SelectItem value="delegated">مفوضة</SelectItem>
                <SelectItem value="handed">مسلمة</SelectItem>
                <SelectItem value="out_of_service">خارج الخدمة</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {(formData.status === "delegated" || formData.status === "handed") && (
            <>
              <div className="space-y-2">
                <Label htmlFor="current_delegate" className="text-right block">المندوب الحالي</Label>
                <Select value={formData.current_delegate_id} onValueChange={(value) => setFormData({...formData, current_delegate_id: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="اختر المندوب" />
                  </SelectTrigger>
                  <SelectContent>
                    {drivers.map((driver) => (
                      <SelectItem key={driver.id} value={driver.id}>
                        {driver.full_name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="delegation_start" className="text-right block">تاريخ بداية التفويض</Label>
                  <Input
                    id="delegation_start"
                    type="date"
                    value={formData.delegation_start}
                    onChange={(e) => setFormData({...formData, delegation_start: e.target.value})}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="delegation_end" className="text-right block">تاريخ نهاية التفويض</Label>
                  <Input
                    id="delegation_end"
                    type="date"
                    value={formData.delegation_end}
                    onChange={(e) => setFormData({...formData, delegation_end: e.target.value})}
                  />
                </div>
              </div>
            </>
          )}

          <div className="flex justify-end space-x-2 pt-4">
            <Button type="button" variant="outline" onClick={onClose} disabled={loading}>
              إلغاء
            </Button>
            <Button type="submit" disabled={loading} className="glass-button-hover">
              {loading ? "جاري الحفظ..." : car ? "تحديث" : "إضافة"}
            </Button>
          </div>
        </form>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}