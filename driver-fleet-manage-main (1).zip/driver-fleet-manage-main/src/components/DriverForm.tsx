import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface Driver {
  id?: string;
  full_name: string;
  iqama: string;
  license_expiry: string;
  iqama_expiry: string;
  medical_expiry: string;
  status: string;
  manager?: string;
  using_app: boolean;
}

interface DriverFormProps {
  isOpen: boolean;
  onClose: () => void;
  driver?: Driver | null;
  onSave: () => void;
}

export function DriverForm({ isOpen, onClose, driver, onSave }: DriverFormProps) {
  const [formData, setFormData] = useState<Driver>({
    full_name: "",
    iqama: "",
    license_expiry: "",
    iqama_expiry: "",
    medical_expiry: "",
    status: "new",
    manager: "",
    using_app: false,
  });

  // Update form data when driver prop changes
  useEffect(() => {
    if (driver) {
      setFormData({
        full_name: driver.full_name || "",
        iqama: driver.iqama || "",
        license_expiry: driver.license_expiry || "",
        iqama_expiry: driver.iqama_expiry || "",
        medical_expiry: driver.medical_expiry || "",
        status: driver.status || "new",
        manager: driver.manager || "",
        using_app: driver.using_app || false,
      });
    } else {
      // Reset form for new driver
      setFormData({
        full_name: "",
        iqama: "",
        license_expiry: "",
        iqama_expiry: "",
        medical_expiry: "",
        status: "new",
        manager: "",
        using_app: false,
      });
    }
  }, [driver, isOpen]);

  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (driver?.id) {
        // Update existing driver
        const { error } = await supabase
          .from("drivers")
          .update(formData)
          .eq("id", driver.id);
        
        if (error) throw error;
        toast.success("تم تحديث المندوب بنجاح");
      } else {
        // Create new driver
        const { error } = await supabase
          .from("drivers")
          .insert(formData);
        
        if (error) throw error;
        toast.success("تم إضافة المندوب بنجاح");
      }
      
      
      onSave(); // Refresh the data
      onClose(); // Close the modal
      
      // Reset form data
      setFormData({
        full_name: "",
        iqama: "",
        license_expiry: "",
        iqama_expiry: "",
        medical_expiry: "",
        status: "new",
        manager: "",
        using_app: false,
      });
    } catch (error: any) {
      toast.error(error.message || "حدث خطأ");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px] glass-modal max-h-[90vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-right">
            {driver ? "تعديل المندوب" : "إضافة مندوب جديد"}
          </DialogTitle>
        </DialogHeader>
        
        <ScrollArea className="flex-1 pr-4">
          <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div className="space-y-2">
            <Label htmlFor="full_name" className="text-right block">الاسم الكامل</Label>
            <Input
              id="full_name"
              value={formData.full_name}
              onChange={(e) => setFormData({...formData, full_name: e.target.value})}
              required
              className="text-right"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="iqama" className="text-right block">رقم الإقامة</Label>
            <Input
              id="iqama"
              value={formData.iqama}
              onChange={(e) => setFormData({...formData, iqama: e.target.value})}
              required
              className="text-right"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="license_expiry" className="text-right block">انتهاء الرخصة</Label>
              <Input
                id="license_expiry"
                type="date"
                value={formData.license_expiry}
                onChange={(e) => setFormData({...formData, license_expiry: e.target.value})}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="iqama_expiry" className="text-right block">انتهاء الإقامة</Label>
              <Input
                id="iqama_expiry"
                type="date"
                value={formData.iqama_expiry}
                onChange={(e) => setFormData({...formData, iqama_expiry: e.target.value})}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="medical_expiry" className="text-right block">انتهاء الطبي</Label>
              <Input
                id="medical_expiry"
                type="date"
                value={formData.medical_expiry}
                onChange={(e) => setFormData({...formData, medical_expiry: e.target.value})}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="status" className="text-right block">الحالة</Label>
              <Select value={formData.status} onValueChange={(value) => setFormData({...formData, status: value})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="new">جديد</SelectItem>
                  <SelectItem value="accepted">مقبول</SelectItem>
                  <SelectItem value="sponsored">مكفول</SelectItem>
                  <SelectItem value="archived">مؤرشف</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="manager" className="text-right block">المدير</Label>
              <Input
                id="manager"
                value={formData.manager}
                onChange={(e) => setFormData({...formData, manager: e.target.value})}
                className="text-right"
              />
            </div>
          </div>

          <div className="flex items-center space-x-2 justify-end">
            <Label htmlFor="using_app" className="text-right">يستخدم التطبيق</Label>
            <input
              id="using_app"
              type="checkbox"
              checked={formData.using_app}
              onChange={(e) => setFormData({...formData, using_app: e.target.checked})}
              className="rounded"
            />
          </div>

          <div className="flex justify-end space-x-2 pt-4">
            <Button type="button" variant="outline" onClick={onClose} disabled={loading}>
              إلغاء
            </Button>
            <Button type="submit" disabled={loading} className="glass-button-hover">
              {loading ? "جاري الحفظ..." : driver ? "تحديث" : "إضافة"}
            </Button>
          </div>
        </form>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}