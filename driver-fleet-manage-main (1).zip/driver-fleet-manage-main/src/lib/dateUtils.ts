/**
 * Utility functions for date formatting in Arabic context
 */

const arabicMonths = [
  'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
  'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
];

/**
 * Format date in Arabic style: dd/MM/yyyy
 */
export const formatDateArabic = (date: Date | undefined): string => {
  if (!date) return '—';
  
  const day = date.getDate().toString().padStart(2, '0');
  const month = (date.getMonth() + 1).toString().padStart(2, '0');
  const year = date.getFullYear();
  
  return `${day}/${month}/${year}`;
};

/**
 * Format date with Arabic month name: dd MMMM yyyy
 */
export const formatDateArabicLong = (date: Date | undefined): string => {
  if (!date) return '—';
  
  const day = date.getDate();
  const month = arabicMonths[date.getMonth()];
  const year = date.getFullYear();
  
  return `${day} ${month} ${year}`;
};

/**
 * Calculate days between two dates
 */
export const daysBetween = (startDate: Date, endDate: Date): number => {
  const start = startDate instanceof Date ? startDate : new Date(startDate);
  const end = endDate instanceof Date ? endDate : new Date(endDate);
  const diffTime = end.getTime() - start.getTime();
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
};

/**
 * Get current date in Arabic format
 */
export const getCurrentDateArabic = (): string => {
  return formatDateArabic(new Date());
};